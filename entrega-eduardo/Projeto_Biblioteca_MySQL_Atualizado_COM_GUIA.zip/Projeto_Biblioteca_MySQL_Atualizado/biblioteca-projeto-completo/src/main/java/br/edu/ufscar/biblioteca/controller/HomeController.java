package br.edu.ufscar.biblioteca.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class HomeController {
    @GetMapping("/") public String inicio() { return "index"; }
    @GetMapping("/login") public String login() { return "auth/login"; }
}
